<?php

include_once URL_APP . '/views/custom/header.php';

include_once URL_APP . '/views/custom/navbar.php';
?>


<div class="container mt-8 text-center">
    <div class="col text-center">
        <h1>MUGEN ANIME</h1>
        <h6>Entretienete jugando con casi todos los personajes de animes en un MUGEN.Descarga,Juega y Disfruta ;)</h6>
        
    </div>
    <hr>

</div>
<div class="col text-center">
    <iframe width="630" height="320" src="https://acortar.link/mugen" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     
</div>





<div class="col  text-center">
    <p>Download</p>
    <div class="well">
        <a href="http://www.mediafire.com/file/58ewkthzaqxyyf4/JUS_M.U.G.E.N.zip/file"><img src="<?php echo URL_PROJECT ?>/img/descarga2.webp" width="55" height="48"></a>
    </div>
</div>



<?php

include_once URL_APP . '/views/custom/footer.php';

?>