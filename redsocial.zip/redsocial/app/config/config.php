<?php

// definimos las constantes de nuestra base de datos

define('DB_HOST' , 'localhost');
define('DB_NAME' , 'redsocial');
define('DB_USER' , 'root');
define('DB_PASSWORD' , '');

// definir las constantes de nuestro proyecto

define('URL_APP' , dirname(dirname(__FILE__)));
define('URL_PROJECT' , 'http://localhost/redsocial');
define('NAME_PROJECT' , 'Red Social');
