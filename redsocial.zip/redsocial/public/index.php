<?php

// Llmando al iniciador
require_once '../app/initializer.php';


// iniciamos el core
$init = new Core;